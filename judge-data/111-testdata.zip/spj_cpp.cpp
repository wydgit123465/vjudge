#include <bits/stdc++.h>
using namespace std;

string ans[36] = {
    "D", "A", "C", "B", "D", "A", "C", "A", "B", "A",
    "D", "B", "A", "B", "C", "B", "B", "D", "A", "B",
    "C", "B", "B", "B", "A", "B", "A", "A", "B", "A",
    "C", "C", "15", "error", "9178", "'lIl IlII l I IIll l'!"
};

int sum[36] = {
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    2, 2, 2, 2, 2, 2, 3, 3, 3, 3,
    3, 4, 7, 7, 7, 7
};

int main() {
    ifstream fin("user_out");
    
    if (!fin.is_open()) {
        fprintf(stderr, "错误：无法打开用户输出文件\n");
        printf("0\n");
        return 0;
    }

    int num = 0;
    string str;
    int i = 0;
    bool is_valid = true;

    while (fin >> str) {
        if (i >= 36) break;

        int idx = i; 
        int current_score = 0;

        if (idx == 34 && str != "9178") {
            is_valid = false;
        }

        if (idx < 36) {
            if (str == ans[idx]) {
                current_score = sum[idx];
                num += current_score;
            }
            
            fprintf(stderr, "题号 %d: 用户答案='%s', 正确答案='%s', 得分=%d\n", 
                    idx + 1, str.c_str(), ans[idx].c_str(), current_score);
        }
        
        i++;
    }

    if (!is_valid) {
        num = 0;
    }

    printf("%d\n", num);
    return 0;
}

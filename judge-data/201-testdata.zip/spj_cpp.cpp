#include <bits/stdc++.h>
using namespace std;

string ans[36] = {
    "D", "A", "C", "B", "D", "A", "C", "A", "B", "A",
    "D", "B", "A", "B", "C", "B", "B", "D", "A", "B",
    "C", "B", "B", "B", "A", "B", "A", "A", "B", "A",
    "C", "C", "10", "error", "9178", "\'lIl IlII l I IIll l\'!"
};

// 权重调整后总和为 100，且每一项均为整数
int sum[36] = {
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
    2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2,
    2,
    4, 4, 4, 4
};

int main() {
    ifstream fin("user_out");
    
    if (!fin.is_open()) {
        fprintf(stderr, "错误：无法打开用户输出文件\n");
        printf("0\n");
        return 0;
    }

    int total_score = 0;
    string str;
    int i = 0;
    bool is_valid = true;

    while (fin >> str) {
        if (i >= 36) break;

        if (i == 35) {
            string rest;
            getline(fin, rest);
            str += rest;
        }

        if (i == 34 && str != "9178") {
            is_valid = false;
        }

        if (str == ans[i]) {
            total_score += sum[i];
        }
        
        fprintf(stderr, "题号 %d: 用户答案='%s', 得分=%d\n", i + 1, str.c_str(), (str == ans[i] ? sum[i] : 0));
        i++;
    }

    fin.close();

    if (!is_valid) {
        total_score = 0;
    }

    printf("%d\n", total_score);
    return 0;
}
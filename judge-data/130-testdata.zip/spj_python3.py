import sys
import random

def read_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except:
        return ''

def generate_hardcoded_zones():
    """生成 9 个独立的 9x9 区块。"""
    zones = {}
    rng = random.Random(42)
    
    # 区块 0: 玩家起点，散布数字
    zone0 = [['.' for _ in range(9)] for _ in range(9)]
    nums = list('123456789') * 5
    rng.shuffle(nums)
    idx = 0
    for r in range(9):
        for c in range(9):
            if r == 4 and c == 4: continue
            if rng.random() < 0.6 and idx < len(nums):
                zone0[r][c] = nums[idx]
                idx += 1
    zones[0] = zone0
    
    # 区块 1: 散布数字
    zone1 = [['.' for _ in range(9)] for _ in range(9)]
    nums2 = list('123456789') * 4
    rng.shuffle(nums2)
    idx2 = 0
    for r in range(9):
        for c in range(9):
            if rng.random() < 0.5 and idx2 < len(nums2):
                zone1[r][c] = nums2[idx2]
                idx2 += 1
    zones[1] = zone1
    
    # 区块 2, 3: 迷宫区
    for z_id in [2, 3]:
        z = [['.' for _ in range(9)] for _ in range(9)]
        for _ in range(10):
            r, c = rng.randint(0, 8), rng.randint(0, 8)
            z[r][c] = '#'
        zones[z_id] = z
        
    # 区块 4: 目标合成区，全空
    zones[4] = [['.' for _ in range(9)] for _ in range(9)]
    
    # 区块 5-8: 空区块
    for z_id in [5, 6, 7, 8]:
        zones[z_id] = [['.' for _ in range(9)] for _ in range(9)]
        
    return zones

def generate_transitions():
    """
    定义区块间的空间跳跃关系。
    实现：“上 -> 右 -> 下 -> 左” 走一圈不回到原区块。
    """
    return {
        0: {'W': (1, 8, 4)},  # 0向上走，到1的下方
        1: {'D': (2, 4, 0)},  # 1向右走，到2的左侧
        2: {'S': (3, 0, 4)},  # 2向下走，到3的上方
        3: {'A': (4, 4, 8)},  # 3向左走，到4的右侧
        
        4: {'W': (0, 8, 4)},  # 4向上走，回到0的下方
    }

def is_full_sudoku(region):
    if len(region) != 9 or any(len(row) != 9 for row in region):
        return False
    for r in range(9):
        if sorted(region[r]) != list('123456789'): return False
    for c in range(9):
        col = [region[r][c] for r in range(9)]
        if sorted(col) != list('123456789'): return False
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            block = [region[r][c] for r in range(br, br+3) for c in range(bc, bc+3)]
            if sorted(block) != list('123456789'): return False
    return True

def count_valid_lines(region):
    score = 0
    for r in range(9):
        if sorted(region[r]) == list('123456789'): score += 1
    for c in range(9):
        col = [region[r][c] for r in range(9)]
        if sorted(col) == list('123456789'): score += 1
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            block = [region[r][c] for r in range(br, br+3) for c in range(bc, bc+3)]
            if sorted(block) == list('123456789'): score += 1
    return score

def simulate(zones, start_zone, start_pos, operations, transitions):
    """模拟跨区块的玩家操作"""
    current_zone = start_zone
    r, c = start_pos
    dirs = {'W': (-1, 0), 'S': (1, 0), 'A': (0, -1), 'D': (0, 1)}
    
    for op in operations:
        if op not in dirs: continue
        dr, dc = dirs[op]
        nr, nc = r + dr, c + dc
        
        if 0 <= nr < 9 and 0 <= nc < 9:
            target = zones[current_zone][nr][nc]
            if target == '#':
                continue
            elif target == '.':
                r, c = nr, nc
            elif target.isdigit():
                nnr, nnc = nr + dr, nc + dc
                # 数字不能推出区块边界
                if 0 <= nnr < 9 and 0 <= nnc < 9:
                    next_target = zones[current_zone][nnr][nnc]
                    if next_target == '.':
                        zones[current_zone][nnr][nnc] = target
                        zones[current_zone][nr][nc] = '.'
                        r, c = nr, nc
        else:
            # 越界，触发区块跳跃
            if current_zone in transitions and op in transitions[current_zone]:
                next_z, er, ec = transitions[current_zone][op]
                if zones[next_z][er][ec] != '#':
                    current_zone = next_z
                    r, c = er, ec

    return zones, current_zone, r, c

def main():
    user_str = read_file('user_out')
    
    # 1. 检查满分彩蛋
    if "I am Sudoku King." in user_str:
        print(100)
        sys.exit(0)
        
    if not user_str.strip():
        print(0); sys.exit(0)
        
    ops = [ch.upper() for ch in user_str if ch.upper() in 'WASD']
    
    zones = generate_hardcoded_zones()
    transitions = generate_transitions()
    
    start_zone = 0
    start_pos = (4, 4)
    
    # 2. 模拟玩家操作，并获取最终位置
    final_zones, final_z, final_r, final_c = simulate(zones, start_zone, start_pos, ops, transitions)
    
    # 复制一份当前区块用于显示，把玩家位置标上 'P'
    display_grid = [row[:] for row in final_zones[final_z]]
    original_char = display_grid[final_r][final_c]
    # 如果玩家站在空地上，显示 P；如果站在数字上(理论上正常模拟不会发生)，显示 p
    display_grid[final_r][final_c] = 'P' if original_char == '.' else 'p'
    
    # 打印地图
    for row in display_grid:
        print(f"{''.join(row)}", file=sys.stderr)
    
    # 4. 遍历所有区块检查数独完成情况并计算部分分
    has_full_sudoku = False
    total_valid_lines = 0
    max_possible_lines = 0
    
    for z_id, grid in final_zones.items():
        if is_full_sudoku(grid):
            has_full_sudoku = True
        total_valid_lines += count_valid_lines(grid)
        max_possible_lines += 27

    # 5. 输出最终得分
    if has_full_sudoku:
        print(100)
    else:
        score = int(total_valid_lines / max_possible_lines * 100) if max_possible_lines > 0 else 0
        print(score)

if __name__ == '__main__':
    main()
import sys
import re

def read_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read().strip()
    except Exception as e:
        print(f"SPJ Error reading {path}: {e}", file=sys.stderr)
        return ''

def rotate_face_90(face_str):
    f = list(face_str)
    return "".join([f[6], f[3], f[0], f[7], f[4], f[1], f[8], f[5], f[2]])

def sim_move(faces_dict, move):
    if move == 'U':
        faces_dict['U'] = rotate_face_90(faces_dict['U'])
        t = faces_dict['F'][0:3]
        faces_dict['F'] = faces_dict['R'][0:3] + faces_dict['F'][3:]
        faces_dict['R'] = faces_dict['B'][0:3] + faces_dict['R'][3:]
        faces_dict['B'] = faces_dict['L'][0:3] + faces_dict['B'][3:]
        faces_dict['L'] = t + faces_dict['L'][3:]
    elif move == 'D':
        faces_dict['D'] = rotate_face_90(faces_dict['D'])
        t = faces_dict['F'][6:9]
        faces_dict['F'] = faces_dict['F'][0:6] + faces_dict['L'][6:9]
        faces_dict['L'] = faces_dict['L'][0:6] + faces_dict['B'][6:9]
        faces_dict['B'] = faces_dict['B'][0:6] + faces_dict['R'][6:9]
        faces_dict['R'] = faces_dict['R'][0:6] + t
    elif move == 'R':
        faces_dict['R'] = rotate_face_90(faces_dict['R'])
        u, b, d, f = list(faces_dict['U']), list(faces_dict['B']), list(faces_dict['D']), list(faces_dict['F'])
        t2, t5, t8 = u[2], u[5], u[8]
        u[2], u[5], u[8] = f[2], f[5], f[8]
        f[2], f[5], f[8] = d[2], d[5], d[8]
        d[2], d[5], d[8] = b[6], b[3], b[0]
        b[6], b[3], b[0] = t2, t5, t8
        faces_dict['U'], faces_dict['B'], faces_dict['D'], faces_dict['F'] = "".join(u), "".join(b), "".join(d), "".join(f)
    elif move == 'L':
        faces_dict['L'] = rotate_face_90(faces_dict['L'])
        u, f, d, b = list(faces_dict['U']), list(faces_dict['F']), list(faces_dict['D']), list(faces_dict['B'])
        t0, t3, t6 = u[0], u[3], u[6]
        u[0], u[3], u[6] = b[8], b[5], b[2]
        b[8], b[5], b[2] = d[0], d[3], d[6]
        d[0], d[3], d[6] = f[0], f[3], f[6]
        f[0], f[3], f[6] = t0, t3, t6
        faces_dict['U'], faces_dict['F'], faces_dict['D'], faces_dict['B'] = "".join(u), "".join(f), "".join(d), "".join(b)
    elif move == 'F':
        faces_dict['F'] = rotate_face_90(faces_dict['F'])
        u, r, d, l = list(faces_dict['U']), list(faces_dict['R']), list(faces_dict['D']), list(faces_dict['L'])
        t6, t7, t8 = u[6], u[7], u[8]
        u[6], u[7], u[8] = l[8], l[5], l[2]
        l[2], l[5], l[8] = d[0], d[1], d[2]
        d[0], d[1], d[2] = r[6], r[3], r[0]
        r[0], r[3], r[6] = t6, t7, t8
        faces_dict['U'], faces_dict['R'], faces_dict['D'], faces_dict['L'] = "".join(u), "".join(r), "".join(d), "".join(l)
    elif move == 'B':
        faces_dict['B'] = rotate_face_90(faces_dict['B'])
        u, l, d, r = list(faces_dict['U']), list(faces_dict['L']), list(faces_dict['D']), list(faces_dict['R'])
        t2, t1, t0 = u[2], u[1], u[0]
        u[0], u[1], u[2] = r[2], r[5], r[8]
        r[2], r[5], r[8] = d[8], d[7], d[6]
        d[6], d[7], d[8] = l[6], l[3], l[0]
        l[0], l[3], l[6] = t0, t1, t2
        faces_dict['U'], faces_dict['L'], faces_dict['D'], faces_dict['R'] = "".join(u), "".join(l), "".join(d), "".join(r)

def judge():
    inp = read_file('input').strip().split('\n')
    user_raw = read_file('user_out').strip()
    
    if not user_raw:
        print(0)
        print("Wrong Answer: User output is completely empty.", file=sys.stderr)
        return

    # ==================== 智能模糊彩蛋规则校验 ====================
    # 1. 转化为全小写
    user_lower = user_raw.lower()
    # 2. 移除非字母字符（去除句号、单引号等标点影响），并将连续空格压缩为单个
    user_clean = re.sub(r'[^a-z\s]', '', user_lower)
    user_clean = " ".join(user_clean.split())

    # 3. 关键词提取判断法：检查是否包含了归还、魔方、同学的核心语义
    has_return = ('return' in user_clean) or ('give' in user_clean and 'back' in user_clean) or ('send' in user_clean)
    has_cube = ('cube' in user_clean) or ('rubik' in user_clean)
    has_classmate = ('classmate' in user_clean) or ('friend' in user_clean) or ('student' in user_clean)

    if has_return and has_cube and has_classmate:
        print(100)
        print(f"Accepted: Easter Egg Triggered! Matched semantic meaning from: '{user_raw}'", file=sys.stderr)
        return
    # =============================================================

    user = user_raw.split()
    if len(inp) < 6:
        print(0)
        print("SPJ Error: Invalid input file format (less than 6 faces).", file=sys.stderr)
        return
        
    face_order = ['U', 'D', 'L', 'R', 'F', 'B']
    faces_dict = {face_order[i]: inp[i].strip() for i in range(6)}

    try:
        user_k = int(user[0])
    except ValueError:
        print(0)
        print(f"Wrong Answer: First token is neither a valid step integer nor a matched easter egg.", file=sys.stderr)
        return

    if user_k < 0 or user_k > 30:
        print(0)
        print(f"Wrong Answer: Step count K={user_k} is out of bounds.", file=sys.stderr)
        return

    moves = user[1:]
    if len(moves) != user_k:
        print(0)
        print(f"Wrong Answer: K={user_k} but found {len(moves)} move commands.", file=sys.stderr)
        return

    valid_ops = {'U', 'D', 'R', 'L', 'F', 'B'}
    for step_idx, mv in enumerate(moves):
        if mv not in valid_ops:
            print(0)
            print(f"Wrong Answer: Invalid move token '{mv}' at step {step_idx+1}.", file=sys.stderr)
            return
        sim_move(faces_dict, mv)

    std_colors = {'U': 'W', 'D': 'Y', 'L': 'O', 'R': 'R', 'F': 'G', 'B': 'B'}
    for face, s in faces_dict.items():
        expected_c = std_colors[face]
        for idx, char in enumerate(s):
            if char != expected_c:
                print(0)
                print(f"Wrong Answer: Face {face} index {idx} failed to restore. Expected '{expected_c}', got '{char}'.", file=sys.stderr)
                return

    print(100)
    print(f"Accepted: Cube fully restored in {user_k} steps!", file=sys.stderr)

if __name__ == '__main__':
    judge()

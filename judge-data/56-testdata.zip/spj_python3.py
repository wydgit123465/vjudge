import sys

def read_file(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except:
        return ''

def parse_input(inp_str):
    """
    解析大地图
    假设格式：
    第一行 N M (大地图总行数和列数，例如 27 27)
    接下来 N 行 M 列的地图字符
    """
    lines = inp_str.strip().split('\n')
    if not lines: return None, None, 0, 0
    
    try:
        N, M = map(int, lines[0].split())
    except:
        # 兼容没有给出长宽的情况，自动推断
        N = len(lines) - 1
        M = len(lines[1]) if N > 0 else 0
        lines.insert(0, f"{N} {M}")

    grid = []
    player_pos = None
    
    for i in range(1, N + 1):
        # 保证每行长度一致，不足补 '.'
        row = list(lines[i].ljust(M, '.'))
        if 'P' in row:
            player_pos = (i - 1, row.index('P'))
            row[row.index('P')] = '.' # 玩家位置在地图中视为空地，坐标单独维护
        grid.append(row)
        
    return grid, player_pos, N, M

def is_full_sudoku(region):
    """检查 9x9 区域是否是完整的合法数独"""
    if len(region) != 9 or any(len(row) != 9 for row in region):
        return False
    # 检查行
    for r in range(9):
        if sorted(region[r]) != list('123456789'): return False
    # 检查列
    for c in range(9):
        col = [region[r][c] for r in range(9)]
        if sorted(col) != list('123456789'): return False
    # 检查 3x3 宫格
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            block = [region[r][c] for r in range(br, br+3) for c in range(bc, bc+3)]
            if sorted(block) != list('123456789'): return False
    return True

def count_valid_lines(region):
    """统计一个 9x9 区域中合法的行、列、宫数量 (用于部分分)"""
    score = 0
    # 合法行
    for r in range(9):
        if sorted(region[r]) == list('123456789'): score += 1
    # 合法列
    for c in range(9):
        col = [region[r][c] for r in range(9)]
        if sorted(col) == list('123456789'): score += 1
    # 合法 3x3 宫格
    for br in range(0, 9, 3):
        for bc in range(0, 9, 3):
            block = [region[r][c] for r in range(br, br+3) for c in range(bc, bc+3)]
            if sorted(block) == list('123456789'): score += 1
    return score

def simulate(grid, player_pos, operations, N, M):
    """模拟全局操作"""
    r, c = player_pos
    dirs = {'W': (-1, 0), 'S': (1, 0), 'A': (0, -1), 'D': (0, 1)}
    
    # 预处理寻找成对的传送门
    portals = {}
    portal_list = []
    for i in range(N):
        for j in range(M):
            if grid[i][j] == 'O':
                portal_list.append((i, j))
    # 假设传送门两两配对
    for k in range(0, len(portal_list) - 1, 2):
        p1, p2 = portal_list[k], portal_list[k+1]
        portals[p1] = p2
        portals[p2] = p1

    for op in operations:
        if op not in dirs: continue
        dr, dc = dirs[op]
        nr, nc = r + dr, c + dc
        
        # 越界检查
        if not (0 <= nr < N and 0 <= nc < M): continue
            
        target = grid[nr][nc]
        
        if target == '#':
            continue # 障碍物阻挡，不能直接穿过去
        elif target == '.':
            r, c = nr, nc
        elif target == 'O': 
            # 传送门
            if (nr, nc) in portals:
                r, c = portals[(nr, nc)]
        elif target.isdigit(): 
            # 推数字
            nnr, nnc = nr + dr, nc + dc
            if 0 <= nnr < N and 0 <= nnc < M:
                next_target = grid[nnr][nnc]
                if next_target == '.':
                    grid[nnr][nnc] = target
                    grid[nr][nc] = '.'
                    r, c = nr, nc
    return grid

def main():
    inp_str = read_file('input')
    user_str = read_file('user_out')
    
    # 1. 检查满分彩蛋
    if "I am Sudoku King." in user_str:
        print(100)
        print("Sudoku King detected! Direct 100 points.", file=sys.stderr)
        sys.exit(0)
        
    if not user_str.strip():
        print(0)
        sys.exit(0)
        
    # 2. 提取合法操作序列
    ops = [ch.upper() for ch in user_str if ch.upper() in 'WASD']
    
    # 3. 解析地图
    grid, player_pos, N, M = parse_input(inp_str)
    if grid is None or player_pos is None:
        print(0)
        print("Map parse error or player missing.", file=sys.stderr)
        sys.exit(0)
        
    # 4. 模拟玩家操作
    final_grid = simulate(grid, player_pos, ops, N, M)
    
    # 5. 遍历所有 9x9 区块计算得分
    has_full_sudoku = False
    total_valid_lines = 0
    max_possible_lines = 0
    
    # 按照 9 的步长遍历大地图中的所有 9x9 区块
    start_rs = [i for i in range(0, N - 8, 9)]
    start_cs = [j for j in range(0, M - 8, 9)]
    
    # 如果地图不是 9 的倍数，至少检查从 (0,0) 开始的区域
    if not start_rs: start_rs = [0]
    if not start_cs: start_cs = [0]

    for start_r in start_rs:
        for start_c in start_cs:
            region = []
            for i in range(9):
                if start_r + i < N:
                    row_data = final_grid[start_r + i][start_c : start_c+9]
                    row_data += ['.'] * (9 - len(row_data)) # 不足补齐
                    region.append(row_data)
                else:
                    region.append(['.'] * 9)
            
            # 检查是否合成完整数独
            if is_full_sudoku(region):
                has_full_sudoku = True
            
            # 统计部分分
            total_valid_lines += count_valid_lines(region)
            max_possible_lines += 27 # 每个区块最多 27 个合法线（9行+9列+9宫）

    # 6. 输出最终得分
    if has_full_sudoku:
        print(100)
        print("Completed a full Sudoku!", file=sys.stderr)
    else:
        # 给出部分分 (最高限制在 99 分，保证只有真的解出来才有 100 分)
        score = int(total_valid_lines / max_possible_lines * 100) if max_possible_lines > 0 else 0
        print(score)
        print(f"Partial score: {total_valid_lines}/{max_possible_lines} valid lines.", file=sys.stderr)

if __name__ == '__main__':
    main()
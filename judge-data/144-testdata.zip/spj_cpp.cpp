#include <bits/stdc++.h>
using namespace std;

// 读取整个文件的所有行，便于处理行数限制
vector<string> read_all_lines(const string& filepath) {
    vector<string> lines;
    ifstream infile(filepath);
    if (!infile.is_open()) return lines;
    string line;
    while (getline(infile, line)) {
        // 去除行末的回车符（兼容 Windows 的 \r\n）
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        lines.push_back(line);
    }
    return lines;
}

int main() {
    // 1. 打开并读取输入数据（获取测试点编号 n）
    ifstream fin("input");
    int n = 0;
    if (fin >> n) {
        // 成功读入 n
    }
    fin.close();

    // 根据规则 6：建立测试点编号与标准答案的映射
    string item_name = "";
    if (n == 1) item_name = "GONGZUOTAI";
    else if (n == 2) item_name = "JIYAN";
    else if (n == 3) item_name = "XIAJIESHUIJING";
    else if (n == 4) item_name = "RONGLU";
    else if (n == 5) item_name = "JIYAN";
    else if (n == 6) item_name = "XIAJIESHUIJING";
    else if (n == 7) item_name = "RONGLU";

    // 2. 读取选手的输出文件
    vector<string> user_lines = read_all_lines("user_out");

    // 规则 5：如果用户输入超过 3 行，直接给 0 分，无任何调试信息
    if (user_lines.size() > 3) {
        printf("0\n");
        return 0;
    }

    // 如果选手什么都没输出，或者第一行为空
    if (user_lines.empty() || user_lines[0].empty()) {
        printf("0\n");
        return 0;
    }

    // 提取第一行的第一个字符
    char first_char = user_lines[0][0];

    // 规则 1：如果第一行第一个字符不为 '?' 或 '!'，给 0 分且无报错信息
    if (first_char != '?' && first_char != '!') {
        printf("0\n");
        return 0;
    }

    // 规则 2 & 3：处理“边界”和第二行字符的累计
    // 累计的第二行字符串 = 第一行多余的部分 + 选手的实际第二行
    string accum_second = "";
    if (user_lines[0].length() > 1) {
        accum_second += user_lines[0].substr(1); // 第一行除去第一个字符后的剩余部分
    }
    if (user_lines.size() > 1) {
        accum_second += user_lines[1]; // 加上选手的第二行
    }

    // 规则 3：如果累计的第二行字符数量超过 1，直接给 100 分 AC
    if (accum_second.length() > 1) {
        printf("100\n");
        return 0;
    }

    // 如果长度不超过 1，说明长度为 0 或 1。
    // 如果长度为 0，说明选手没提供问题编号或猜测的下标，不符合要求，给 0 分
    if (accum_second.empty()) {
        printf("0\n");
        return 0;
    }

    // 此时第二行长度刚好为 1，获取该字符
    char cmd2 = accum_second[0];

    // 3. 核心判定逻辑：提问（?）或 猜测（!）
    if (first_char == '?') {
        // 选手在提问 A, B, C, D
        string debug_msg = "WA"; // 默认错误输出

        if (item_name == "GONGZUOTAI") {
            if (cmd2 == 'A') debug_msg = "TLE";       // 主世界
            else if (cmd2 == 'B') debug_msg = "MLE";  // 不是建筑材料
            else if (cmd2 == 'C') debug_msg = "TLE";  // 可右键使用
            else if (cmd2 == 'D') debug_msg = "MLE";  // 非红石电路
        } 
        else if (item_name == "RONGLU") {
            if (cmd2 == 'A') debug_msg = "TLE";       // 主世界
            else if (cmd2 == 'B') debug_msg = "MLE";  // 不是建筑材料
            else if (cmd2 == 'C') debug_msg = "TLE";  // 可右键使用
            else if (cmd2 == 'D') debug_msg = "MLE";  // 非红石电路
        } 
        else if (item_name == "JIYAN") {
            if (cmd2 == 'A') debug_msg = "TLE";       // 多个世界都有，最靠前的是主世界 TLE
            else if (cmd2 == 'B') debug_msg = "MLE";  // 不是建筑材料
            else if (cmd2 == 'C') debug_msg = "MLE";  // 不可右键
            else if (cmd2 == 'D') debug_msg = "MLE";  // 非红石
        } 
        else if (item_name == "XIAJIESHUIJING") {
            if (cmd2 == 'A') debug_msg = "RE";        // 自然生成在末地，对应 RE
            else if (cmd2 == 'B') debug_msg = "MLE";  // 不是建筑材料
            else if (cmd2 == 'C') debug_msg = "MLE";  // 无法右键使用
            else if (cmd2 == 'D') debug_msg = "MLE";  // 非红石
        }

        // 提问阶段输出调试信息到 stderr，返回 0 分（等待选手后续进行猜测）
        fprintf(stderr, "%s\n", debug_msg.c_str());
        printf("0\n"); 
    } 
    else if (first_char == '!') {
        // 选手在猜方块。根据您的最新规则：
        // 0:工作台, 1:熔炉, 3:下界水晶, 4:基岩
        
        // 判定下标是否超过有效值（只允许 '0', '1', '3', '4' 这四个合法单字符）
        if (cmd2 != '0' && cmd2 != '1' && cmd2 != '3' && cmd2 != '4') {
            // 如果猜答案时的下标不匹配这些有效数字（或超过这些值），给 0 分且没有任何调试信息输出
            printf("0\n");
            return 0;
        }

        bool is_correct = false;
        if (item_name == "GONGZUOTAI" && cmd2 == '0') is_correct = true;
        else if (item_name == "RONGLU" && cmd2 == '1') is_correct = true;
        else if (item_name == "XIAJIESHUIJING" && cmd2 == '3') is_correct = true;
        else if (item_name == "JIYAN" && cmd2 == '4') is_correct = true;

        if (is_correct) {
            printf("100\n"); // 猜对了，AC
        } else {
            fprintf(stderr, "Wrong Answer! Incorrect guess.\n");
            printf("0\n");   // 猜错了，0 分，附带调试信息
        }
    }

    return 0;
}
    
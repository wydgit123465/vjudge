#ifndef HEADER_H
#define HEADER_H

#include <vector>
#include <iostream>
#include <string>

using namespace std;

// 获取当前战场状态与炸弹组信息
// type: 0~6 分别对应 I, L, T, J, O, S, Z
// r, c: 炸弹组中心点的坐标
// map: 战场状态矩阵
void get(int& type, int& r, int& c, vector<vector<int>>& map) {
    if (!(cin >> type >> r >> c)) return;
    int n = map.size();
    if (n == 0) return;
    int m = map[0].size();
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> map[i][j];
        }
    }
}

// 旋转或平移炸弹组
// op: 0=左移, 1=右移, 2=顺时针旋转90度
void turn(int op) {
    cout << "T " << op << endl;
}

// 发射并结束本回合
void end() {
    cout << "E" << endl;
}

#endif // HEADER_H
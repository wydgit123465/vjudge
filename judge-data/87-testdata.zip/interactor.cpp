#include <bits/stdc++.h>
using namespace std;

// 7种俄罗斯方块初始状态 (以中心点(0,0)为基准，x向下，y向右)
// 分别对应 I, L, T, J, O, S, Z
int shapes_init[7][4][2] = {
    {{0, 0}, {1, 0}, {2, 0}, {3, 0}},          // I
    {{0, 0}, {1, 0}, {2, 0}, {2, 1}},          // L
    {{0, 0}, {1, 0}, {1, 1}, {1, 0}},          // T
    {{0, 0}, {1, 0}, {1, 1}, {1, 2}},          // J
    {{0, 0}, {0, 1}, {1, 0}, {1, 1}},          // O
    {{0, 0}, {1, 0}, {1, 1}, {2, 1}},          // S
    {{0, 0}, {1, -1}, {1, 0}, {2, -1}}         // Z
};
int shapes[7][4][2];

void reset_shapes() {
    memcpy(shapes, shapes_init, sizeof(shapes_init));
}

// 顺时针旋转90度: (x, y) -> (-y, x)
void rotate_shape(int type) {
    for(int i = 0; i < 4; ++i) {
        int x = shapes[type][i][0];
        int y = shapes[type][i][1];
        shapes[type][i][0] = -y;
        shapes[type][i][1] = x;
    }
}

int main() {
    freopen("input", "r", stdin);
    
    int N, M, t;
    if (scanf("%d %d %d", &N, &M, &t) != 3) {
        N = 5; M = 5; t = 5;
    }

    printf("%d %d %d\n", N, M, t);
    fflush(stdout);

    vector<vector<int>> grid(N, vector<int>(M, 0));
    
    bool cheat_code = false;
    bool survived = true;

    for (int sec = 0; sec < t; ++sec) {
        // 检查防线是否被突破
        for (int j = 0; j < M; ++j) {
            if (grid[0][j] == 1) {
                survived = false;
                break;
            }
        }
        if (!survived) break;

        // 大兵向前推进一格 (i -> i-1)
        for (int i = 0; i < N - 1; ++i) {
            grid[i] = grid[i + 1];
        }
        
        // 最后一排补充新大兵，且保证至少 1 个位置没有大兵
        grid[N - 1].assign(M, 0);
        int empty_cnt = 0;
        do {
            empty_cnt = 0;
            for (int j = 0; j < M; ++j) {
                grid[N - 1][j] = (rand() % 3 == 0) ? 1 : 0;
                if (grid[N - 1][j] == 0) empty_cnt++;
            }
        } while (empty_cnt < 1);

        // 生成本回合的炸弹组并重置形状
        reset_shapes();
        int type = rand() % 7;
        int r = rand() % N;
        int c = rand() % M;
        
        // 发送当前状态给选手
        printf("%d %d %d\n", type, r, c);
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < M; ++j) {
                printf("%d ", grid[i][j]);
            }
            printf("\n");
        }
        fflush(stdout);

        // 接收并处理操作（逐行读取以防中文编码截断问题）
        string line;
        while (getline(cin, line)) {
            fprintf(stderr, "[Interactor] Received: [%s] len=%d\n", line.c_str(), (int)line.size());
            // 彩蛋检测
            if (line.find("有了陈二奶奶打辅助") != string::npos) {
                cheat_code = true;
                goto end_game;
            }

            if (line == "E") {
                break;
            } else if (line[0] == 'T') {
                int op_num = 0;
                if (sscanf(line.c_str(), "T %d", &op_num) == 1) {
                    // 0: 左移, 1: 右移, 2: 旋转
                    if (op_num == 0) c--;
                    else if (op_num == 1) c++;
                    else if (op_num == 2) rotate_shape(type);
                }
            }
        }
        
        // 根据最终 r, c 和形状放置炸弹
        for (int k = 0; k < 4; ++k) {
            int rr = r + shapes[type][k][0];
            int cc = c + shapes[type][k][1];
            if (rr >= 0 && rr < N && cc >= 0 && cc < M) {
                grid[rr][cc] = 2; // 2 代表炸弹
            }
        }

        // 检查并处理排满爆炸 (类似俄罗斯方块消行)
        for (int i = 0; i < N; ++i) {
            bool full = true;
            for (int j = 0; j < M; ++j) {
                if (grid[i][j] == 0) {
                    full = false;
                    break;
                }
            }
            if (full) {
                // 爆炸发生，前面的所有排都会后退一格
                for (int k = i; k > 0; --k) {
                    grid[k] = grid[k - 1];
                }
                grid[0].assign(M, 0);
            }
        }
    }

end_game:
    fprintf(stderr, "[Interactor] cheat_code=%d survived=%d\n", cheat_code, survived);
    FILE* sf = fopen("score.txt", "w");
    if (cheat_code || survived) {
        fprintf(sf, "100\n");
        fprintf(stderr, "[Interactor] Score: 100\n");
    } else {
        fprintf(sf, "0\n");
        fprintf(stderr, "[Interactor] Score: 0\n");
    }
    fclose(sf);
    return 0;
}
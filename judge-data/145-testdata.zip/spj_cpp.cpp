#include <bits/stdc++.h>
using namespace std;

int main() {
    // 1. 读取输入文件获取数据组数 t
    ifstream fin("input");
    if (!fin.is_open()) {
        printf("0\n");
        return 0;
    }
    int t = 0;
    fin >> t; // 读取第一行的 t
    fin.close();

    // 2. 读取选手的输出文件中的所有字符串标记（自动忽略多余的空格和换行）
    ifstream fuser("user_out");
    vector<string> user_tokens;
    string token;
    while (fuser >> token) {
        user_tokens.push_back(token);
    }
    fuser.close();

    // 规则 1：判断输出的标记数量是否正好为 t 个，且每一个都必须是 "Yos"
    // 如果不满足，直接给 0 分，无任何调试信息
    if (user_tokens.size() != (size_t)t) {
        printf("0\n");
        return 0;
    }
    for (int i = 0; i < t; i++) {
        if (user_tokens[i] != "Yos") {
            printf("0\n");
            return 0;
        }
    }


    // 规则 2：获取当前 UTC 时间，判断是否对应北京时间的早上 10 点
    time_t now = time(nullptr);
    tm* gmt = gmtime(&now); 

    // 北京时间 10:00~10:59 对应 UTC 时间 02:00~02:59
    if (!gmt || gmt->tm_hour != 2) {
        // 为了调试更直观，我们可以把北京时间也算出来打印
        int beijing_hour = (gmt ? (gmt->tm_hour + 8) % 24 : -1);
        fprintf(stderr, "No this time (Current Beijing hour: %d)\n", beijing_hour);
        printf("0\n");
        return 0;
    }

    // 规则 3：若以上条件都满足，给 100 分 AC
    printf("100\n");
    return 0;
}
